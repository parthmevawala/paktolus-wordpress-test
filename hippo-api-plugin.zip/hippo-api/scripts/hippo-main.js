document.addEventListener("DOMContentLoaded", () => {
    const hippoForm = document.getElementById("hippo_form");
    if (hippoForm) {
        hippoForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const url = local["url"];
            const auth_token = local["auth"];
            const street = document.getElementById("street_address").value;
            const city = document.getElementById("city").value;
            const zip = document.getElementById("zip_code").value;
            const first_name = document.getElementById("f_name").value;
            const last_name = document.getElementById("l_name").value;
            const email = document.getElementById("email").value;
            const phone = document.getElementById("phone").value;
            const dt = new Date(document.getElementById("dob").value);

            const date = dt.getDate().toLocaleString("en-US", {
                minimumIntegerDigits: 2,
                useGrouping: false,
            });

            const month = (dt.getMonth() + 1).toLocaleString("en-US", {
                minimumIntegerDigits: 2,
                useGrouping: false,
            });

            const year = dt.getFullYear();

            const date_of_birth = `${date}${month}${year}`;

            const stateText = document.getElementById("state").value;
            const state = document.querySelector(
                "#state_datalist option[value='" + stateText + "']"
            ).dataset.sc;

            const request = encodeURI(
                `${url}?auth_token=${auth_token}&street=${street}&city=${city}&state=${state}&zip=${zip}&first_name=${first_name}&last_name=${last_name}&email=${email}&phone=${phone}&date_of_birth=${date_of_birth}`
            );

            // Fetch is throwing CORS policyc error.
            fetch(request)
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                });

            // suppose the response from fetch is 
            const response = {
                "quote_url": "https://api.staging.myhippo.io/v1/herd/compare/94d94df3-1fa5-4090-acc6-db83ca9984b5/view",
                "coverage_a": 500000,
                "quote_premium": 1353,
                "quote_id": "94d94df3-1fa5-4090-acc6-db83ca9984b5",
                "hippo_lead_id": "11f3c411-98ae-4e69-a443-36365c57b64e",
                "pscr": ""
            };

            window.location.href = `${local['site_url']}/quote?quote=${response.quote_premium}`;
        });
    }
});

/* https://api.staging.myhippo.io/v1/herd/quote?

auth_token=zcXbR1NoE0zoozyuqAa75s5gBATbeiUsbkGhvb5toGiNWUdDjIUkAU5XgDwCRTet&
street=435%20Homer%20Ave&
city=Palo%20Alto&
state=CA&
zip=94301&
first_name=John&
last_name=Gill&
email=Test%40test.com&
phone=7869885582&
date_of_birth=05061979 */

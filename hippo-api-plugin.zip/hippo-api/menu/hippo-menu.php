<?php
$hippo_settings_auth = get_option('hippo_settings_auth_token');
$hippo_settings_url = get_option('hippo_settings_api_url');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(isset($_POST['auth_token'])) {
        $hippo_settings_auth = $_POST['auth_token'];
        update_option('hippo_settings_auth_token', $hippo_settings_auth);
    }

    if(isset($_POST['api_url'])) {
        $hippo_settings_url = $_POST['api_url'];
        update_option('hippo_settings_api_url', $hippo_settings_url);
    }
}
?>

<div class="container">
    <h1 class="text-center mt-4">Hippo API Settings</h1>
    <form method="POST" class="col-sm-6">
        <div class="form-group my-4">
            <label for="auth_token">Auth Token</label>
            <input type="text" class="form-control" name="auth_token" id="auth_token" value="<?php echo $hippo_settings_auth != false ? $hippo_settings_auth : ''; ?>">
        </div>
        <div class="form-group mb-4">
            <label for="api_url">API Url</label>
            <input type="text" class="form-control" name="api_url" id="api_url" value="<?php echo $hippo_settings_url != false ? $hippo_settings_url : ''; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
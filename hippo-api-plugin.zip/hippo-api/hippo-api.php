<?php

/**
 * Plugin Name: Hippo API
 * Description: This plugin is just for interview purpose.
 * Version: 1.0
 * Author: Parth Mevawala
 **/

// INCLUDING STYLES AND SCRIPTS
function wp_hippo_style_callback()
{
    wp_enqueue_style('bootstrap_style', plugin_dir_url(__FILE__) . 'styles/bootstrap.min.css?' . time(), array(), '5.1.3', 'all');
    wp_enqueue_style('hippo_main_style', plugin_dir_url(__FILE__) . 'styles/style.css?' . time(), array(), false, 'all');

    if (!wp_script_is('jquery', 'enqueued')) {
        wp_enqueue_script('jquery', plugin_dir_url(__FILE__) . 'scripts/jquery-3.6.0.min.js?' . time(), array(), '3.6.0', false);
    }

    wp_enqueue_script('bootstrap_js', plugin_dir_url(__FILE__) . 'scripts/bootstrap.min.js?' . time(), array('jquery'), '5.1.3', true);
    wp_enqueue_script('hippo_main_js', plugin_dir_url(__FILE__) . 'scripts/hippo-main.js?' . time(), array('jquery', 'bootstrap_js'), false, true);

    $hippo_settings_auth = get_option('hippo_settings_auth_token');
    $hippo_settings_url = get_option('hippo_settings_api_url');
    wp_localize_script('hippo_main_js', 'local', array('auth' => $hippo_settings_auth, 'url' => $hippo_settings_url, 'site_url' => site_url()));
}
add_action('wp_enqueue_scripts', 'wp_hippo_style_callback');

function admin_hippo_style_callback()
{
    wp_enqueue_style('bootstrap_style', plugin_dir_url(__FILE__) . 'styles/bootstrap.min.css?' . time(), array(), '5.1.3', 'all');

    if (!wp_script_is('jquery', 'enqueued')) {
        wp_enqueue_script('jquery', plugin_dir_url(__FILE__) . 'scripts/jquery-3.6.0.min.js?' . time(), array(), '3.6.0', false);
    }

    wp_enqueue_script('admin_bootstrap_js', plugin_dir_url(__FILE__) . 'scripts/bootstrap.min.js?' . time(), array('jquery'), '5.1.3', true);
}
add_action('admin_enqueue_scripts', 'admin_hippo_style_callback');

// BACK-END ADMIN MENU INIT
function hippo_menu_callback()
{
    require_once(plugin_dir_path(__FILE__) . 'menu/hippo-menu.php');
}

function hippo_admin_menu()
{
    add_menu_page('Hippo API Settings', 'Hippo API', 'manage_options', 'hippo-api-options', 'hippo_menu_callback', 'dashicons-paperclip', 30);
}
add_action('admin_menu', 'hippo_admin_menu');

// FRONT-END FORM SHORTCODE
function sc_hippo_form()
{
    require_once(plugin_dir_path(__FILE__) . 'form/hippo-form.php');
    return;
}
add_shortcode('hippo_form', 'sc_hippo_form');

function sc_hippo_quote()
{
    if(isset($_GET['quote'])) {
        return '<h2>Your Quote Premium is $'.$_GET['quote'].'</h2>';
    }
    return;
}
add_shortcode('hippo_quote', 'sc_hippo_quote');

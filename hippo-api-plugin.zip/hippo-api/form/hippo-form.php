<div class="container">
    <h1 class="mt-4 text-center">HIPPO API</h1>
    <form action="#" method="get" class="mt-4 col" id="hippo_form">
        <div class="row g-3 mb-4">
            <div class="col">
                <label for="f_name" class="form-label">FIRST NAME <span class="red">*</span></label>
                <input type="text" name="f_name" id="f_name" class="form-control" placeholder="Enter your first name..." required>
            </div>
            <div class="col">
                <label for="m_name" class="form-label">MIDDLE NAME</label>
                <input type="text" name="m_name" id="m_name" placeholder="Enter your middle name..." class="form-control">
            </div>
            <div class="col">
                <label for="l_name" class="form-label">LAST NAME <span class="red">*</span></label>
                <input type="text" name="l_name" id="l_name" class="form-control" placeholder="Enter your last name..." required>
            </div>
        </div>
        <div class="row g-3 mb-4">
            <div class="col-md-8">
                <label for="street_address" class="form-label">STREET ADDRESS <span class="red">*</span></label>
                <input type="text" class="form-control" name="street_address" id="street_address" placeholder="Type your address..." required>
            </div>
            <div class="col-md-4">
                <label for="unit" class="form-label">UNIT #</label>
                <input type="text" class="form-control" name="unit" placeholder="Unit name..." id="unit">
            </div>
        </div>
        <div class="row g-3 mb-4">
            <div class="col">
                <label for="city" class="form-label">CITY <span class="red">*</span></label>
                <input type="text" class="form-control" id="city" name="city"  placeholder="Enter your city..." required>
            </div>
            <div class="col">
                <label for="state" class="form-label">STATE <span class="red">*</span></label>
                <input class="form-control" list="state_datalist" id="state" name="state" placeholder="Type to search state...">
                <datalist id="state_datalist" name="state_datalist" required>
                    <?php
                    $file = file_get_contents(plugin_dir_url(__DIR__) . 'assets/us-states.json');
                    $file_array = json_decode($file);
                    foreach ($file_array as $sc => $state) {
                    ?>
                        <option value="<?php echo $state; ?>" data-sc="<?php echo $sc; ?>"><?php echo $sc; ?></option>
                    <?php
                    }
                    ?>
                </datalist>
            </div>

            <div class="col">
                <label for="zip_code" class="form-label">ZIP CODE <span class="red">*</span></label>
                <input type="text" class="form-control" id="zip_code" name="zip_code" placeholder="Enter your zip code..." required>
            </div>
        </div>
        <div class="row g-3 mb-4">
            <div class="col">
                <label for="dob" class="form-label">DATE OF BIRTH <span class="red">*</span></label>
                <input type="date" class="form-control" id="dob" name="dob"  placeholder="Enter your date of birth..." required>
            </div>
            <div class="col">
                <label for="phone" class="form-label">PHONE <span class="red">*</span></label>
                <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter your phone number..." required>
            </div>
            <div class="col">
                <label for="email" class="form-label">EMAIL ADDRESS <span class="red">*</span></label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email..." required>
            </div>
        </div>
        <div class="mb-1">
            <span>IS THIS A HOUSE, CONDO OR HO5? <span class="red">*</span></span>
        </div>
        <div class="row g-3 mb-4">
            <label for="apt_type_radio_house" class="col d-flex border border-2 py-3">
                <div class="col-4">
                    <img src="<?php echo plugin_dir_url(__DIR__) . "images/house.png"; ?>" alt="house icon">
                </div>
                <div class="col-8">
                    <div class="d-flex justify-content-between">
                        <label class="form-label">HOUSE</label>
                        <input class="form-check-input" type="radio" name="apt_type_radio" id="apt_type_radio_house" value="house" checked>
                    </div>
                    <div>
                        <p>This may be a single-family home, townhouse or duplex you own and live in.</p>
                    </div>
                </div>
            </label>
            <div class="col-space"></div>
            <label for="apt_type_radio_condo" class="col d-flex border border-2 py-3">
                <div class="col-4">
                    <img src="<?php echo plugin_dir_url(__DIR__) . "images/condo.png"; ?>" alt="house icon">
                </div>
                <div class="col-8">
                    <div class="d-flex justify-content-between">
                        <label class="form-label">CONDO</label>
                        <input class="form-check-input" type="radio" name="apt_type_radio" id="apt_type_radio_condo" value="condo">
                    </div>
                    <div>
                        <p>This is likely a multi-family building or complex in which you own a unit.</p>
                    </div>
                </div>
            </label>
            <div class="col-space"></div>
            <label for="apt_type_radio_ho5" class="col d-flex border border-2 py-3">
                <div class="col-4">
                    <img src="<?php echo plugin_dir_url(__DIR__) . "images/ho5.png"; ?>" alt="house icon">
                </div>
                <div class="col-8">
                    <div class="d-flex justify-content-between">
                        <label class="form-label">HO5</label>
                        <input class="form-check-input" type="radio" name="apt_type_radio" id="apt_type_radio_ho5" value="ho5">
                    </div>
                    <div>
                        <p>The HO5 is an open perils insurance policy for a single family home or duplex.</p>
                    </div>
                </div>
            </label>
        </div>
        <div class="row g-3 mb-4">
            <div class="col d-flex justify-content-center">
                <button class="btn btn-success btn-round px-5 py-2" type="submit">SUBMIT</button>
            </div>
        </div>
    </form>
</div>